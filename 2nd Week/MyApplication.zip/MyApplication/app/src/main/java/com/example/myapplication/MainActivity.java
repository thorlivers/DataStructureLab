package com.example.myapplication;

import android.app.Activity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    private Spinner symptom31;
    private Spinner symptom141;
    private Spinner symptom151;
    private Spinner symptom181;
    private Spinner symptom211;

    int SpinSelect3;
    int SpinSelect14;
    int SpinSelect15;
    int SpinSelect18;
    int SpinSelect21;

    String SpinSelect3Data;
    String SpinSelect14Data;
    String SpinSelect15Data;
    String SpinSelect18Data;
    String SpinSelect21Data;
    String disease;
    String diseaseName;

    String url = "http://178.128.56.110/buffalo/api.php";

    final Context c = this;

    private ArrayList<String> symptom3 = new ArrayList<String>();
    private ArrayList<String> symptom14 = new ArrayList<String>();
    private ArrayList<String> symptom15 = new ArrayList<String>();
    private ArrayList<String> symptom18 = new ArrayList<String>();
    private ArrayList<String> symptom21 = new ArrayList<String>();

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        symptom31 = (Spinner) findViewById(R.id.symptom3);
        symptom141 = (Spinner) findViewById(R.id.symptom14);
        symptom151 = (Spinner) findViewById(R.id.symptom15);
        symptom181 = (Spinner) findViewById(R.id.symptom18);
        symptom211 = (Spinner) findViewById(R.id.symptom21);

        createSymptom3Data();
        createSymptom14Data();
        createSymptom15Data();
        createSymptom18Data();
        createSymptom21Data();

        ArrayAdapter<String> adapterSymptom3 = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, symptom3);
        ArrayAdapter<String> adapterSymptom14 = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, symptom14);
        ArrayAdapter<String> adapterSymptom15 = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, symptom15);
        ArrayAdapter<String> adapterSymptom18 = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, symptom18);
        ArrayAdapter<String> adapterSymptom21 = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, symptom21);

        symptom31.setAdapter(adapterSymptom3);
        symptom141.setAdapter(adapterSymptom14);
        symptom151.setAdapter(adapterSymptom15);
        symptom181.setAdapter(adapterSymptom18);
        symptom211.setAdapter(adapterSymptom21);

        symptom31.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MainActivity.this,
//                        "Select : " + symptom3.get(position),
//                        Toast.LENGTH_SHORT).show();
                SpinSelect3 = symptom31.getSelectedItemPosition();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        symptom141.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinSelect14 = symptom141.getSelectedItemPosition();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        symptom151.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinSelect15 = symptom151.getSelectedItemPosition();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        symptom181.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinSelect18 = symptom181.getSelectedItemPosition();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        symptom211.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinSelect21 = symptom211.getSelectedItemPosition();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        final Button analysisBTN = findViewById(R.id.analysisBTN);
        analysisBTN.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (SpinSelect3 == 0 || SpinSelect14 == 0 || SpinSelect15 == 0 || SpinSelect18 == 0 || SpinSelect21 == 0) {
                    Toast.makeText(MainActivity.this,
                            "กรุณาเลือกข้อมูลให้ครบทุกข้อ",Toast.LENGTH_SHORT).show();
                } else {
                    switch(SpinSelect3) {
                        case 1:
                            SpinSelect3Data = "AC1"; break;
                        case 2:
                            SpinSelect3Data = "AC2"; break;
                        case 3:
                            SpinSelect3Data = "AC3"; break;
                    }
                    switch(SpinSelect14) {
                        case 1:
                            SpinSelect14Data = "AN1"; break;
                        case 2:
                            SpinSelect14Data = "AN2"; break;
                    }
                    switch(SpinSelect15) {
                        case 1:
                            SpinSelect15Data = "AO1"; break;
                        case 2:
                            SpinSelect15Data = "AO2"; break;
                    }
                    switch(SpinSelect18) {
                        case 1:
                            SpinSelect18Data = "AR1"; break;
                        case 2:
                            SpinSelect18Data = "AR2"; break;
                    }
                    switch(SpinSelect21) {
                        case 1:
                            SpinSelect21Data = "AU1"; break;
                        case 2:
                            SpinSelect21Data = "AU2"; break;
                    }

//                  Toast.makeText(MainActivity.this, "Select : " + SpinSelect3Data + "," + SpinSelect14Data + "," + SpinSelect15Data + "," + SpinSelect18Data + "," + SpinSelect21Data, Toast.LENGTH_SHORT).show();
                    sendjsrequest();
                }

            }
            private void sendjsrequest() {
                RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
                StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject j = new JSONObject(response);
                            disease = j.getString("disease");

                            switch(disease) {
                                case "anthraxdisease":
                                    diseaseName = "Anthrax Disease: โรคแอนแทรกซ์"; break;
                                case "hemorrhagicsepticemia":
                                    diseaseName = "Hemorrhagicsepticemia: ภาวะโลหิตเป็นพิษในกระแสเลือด"; break;
                                case "brucellosis":
                                    diseaseName = "Brucellosis: โรคแท้งติดต่อ"; break;
                                case "foodandmouthdisease":
                                    diseaseName = "Foodandmouthdisease: โรคปากและเท้าเปื่อย"; break;
                                case "parasiticdisease":
                                    diseaseName = "Parasitic Disease: โรคพยาธิ"; break;
                                case "mastitis":
                                    diseaseName = "Mastitis: โรคนมอักเสบ"; break;
                            }
                            Toast.makeText(MainActivity.this, diseaseName, Toast.LENGTH_SHORT).show();

                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("Hooray!");
                            builder.setMessage("You did it!");
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("สัตว์ของคุณเป็นโรค")
                                        .setMessage(diseaseName)
                                        .setIcon(R.drawable.disease)
                                        .setPositiveButton("บันทึก",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {
                                                        Toast.makeText(MainActivity.this, "บันทึกข้อมูลเรียบร้อย", Toast.LENGTH_SHORT).show();
                                                        dialog.cancel();
                                                    }
                                                })
                                        .setNegativeButton("ไม่บันทึก", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                Toast.makeText(MainActivity.this, "ข้อมูลไม่ถูกบันทึก", Toast.LENGTH_SHORT).show();
                                                dialog.cancel();
                                            }
                                        }).show();


                        } catch (JSONException e) {
                            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
                    protected Map<String, String> getParams(){
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Symptom3", SpinSelect3Data);
                        params.put("Symptom14", SpinSelect14Data);
                        params.put("Symptom15", SpinSelect15Data);
                        params.put("Symptom18", SpinSelect18Data);
                        params.put("Symptom21", SpinSelect21Data);
                        return params;
                    }
                };
                requestQueue.add(request);
            }

        });

    }

    private void createSymptom3Data() {
        symptom3.add("เลือก");
        symptom3.add("หายใจเร็วและถี่\n");
        symptom3.add("หายใจลำบาก\n");
        symptom3.add("หายใจปกติ");
    }

    private void createSymptom14Data() {
        symptom14.add("เลือก");
        symptom14.add("เป็นตะกอนหรือมีหนอง\n");
        symptom14.add("ปกติ");
    }

    private void createSymptom15Data() {
        symptom15.add("เลือก");
        symptom15.add("มีรกค้าง\n");
        symptom15.add("ไม่มีรกค้าง");
    }

    private void createSymptom18Data() {
        symptom18.add("เลือก");
        symptom18.add("มี\n");
        symptom18.add("ไม่มี");
    }

    private void createSymptom21Data() {
        symptom21.add("เลือก");
        symptom21.add("มี\n");
        symptom21.add("ปกติ");
    }


}
